package com.example.jaijith.pdm;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText UsernameEt, PasswordEt;

    @Override


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button login = (Button) findViewById(R.id.login);
        TextView viewwebsiteapp = (TextView) findViewById(R.id.webpage);

        UsernameEt= (EditText)findViewById(R.id.username);
        PasswordEt= (EditText)findViewById(R.id.password);

        viewwebsiteapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String url = "https://document-manager.000webhostapp.com/home.php";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(intent);



            }
        });


    }
    public void OnLogin(View view) {
        String username1 = UsernameEt.getText().toString();
        String password1 = PasswordEt.getText().toString();
        String type= "login";

        BackgroundWorker backgroundWorker=new BackgroundWorker(this);
        backgroundWorker.execute(type,username1,password1);

    }


    public void OpenReg(View view) {
        startActivity(new Intent(this,RegisterActivity.class));
    }
}

