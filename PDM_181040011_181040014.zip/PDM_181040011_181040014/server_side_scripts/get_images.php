<?php
require_once('conn.php');


if(isset($_GET['doc_name']) && !empty($_GET['doc_name'])){
    $doc_name = $_GET['doc_name'];
	$sql = "SELECT * FROM images where name='".$doc_name."'";
	$r = mysqli_query($conn,$sql);
	$result = array();
	
	$res = mysqli_fetch_array($r);

	array_push($result,array(
	    "image"=>$res['images']
	));
	echo json_encode($res['images']);

} else {
	
	$sql = "SELECT * FROM images";
	$r = mysqli_query($conn,$sql);
	$result = array();

	while($res = mysqli_fetch_array($r)){
	array_push($result,array(
	"name"=>$res['name'],
	"images"=>$res['images']
	)
	);
	}
	echo json_encode(array("result"=>$result));
}
mysqli_close($conn);
?>