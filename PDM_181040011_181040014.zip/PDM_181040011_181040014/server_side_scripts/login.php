<?php
require "conn.php";
/*$user_name='123';
$user_pass='123';*/
$user_name=$_POST["user_name"];
$user_pass=$_POST["password"];
$mysql_qry="select * from login where username ='$user_name' and password='$user_pass';";
#$mysql_qry="select * from students where username ='123';";
$result=mysqli_query($conn, $mysql_qry);
if(mysqli_num_rows($result) > 0) {
	$row =mysqli_fetch_assoc($result);
	$name =$row["name"];
	#echo "login success !!!! Welcome " . $name ;;
	echo "login success !!!! Welcome ";;
}
else {
	echo "login not success";
}
?>