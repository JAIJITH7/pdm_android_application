package com.example.jaijith.pdm;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class
DocumentActivity extends AppCompatActivity {

    ImageView _docImage;
    String baseURL = "http://172.20.10.4/get_images.php?doc_name=";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_document);

        Intent intent = getIntent();

        String docType = intent.getStringExtra("doc_type");
        Toast.makeText(getApplicationContext(), docType, Toast.LENGTH_LONG).show();
        _docImage = findViewById(R.id.doc_iimage);

        getImageURL(baseURL+docType);

    }


    private void getImageURL(String resourceURL) {
        class GetURLs extends AsyncTask<String, Void, String> {
            ProgressDialog loading;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(DocumentActivity.this, "Loading...", "Please Wait...", true, true);
            }
            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                Log.v("onPostExecute",s);
                getImage(s);
            }
            @Override
            protected String doInBackground(String... strings) {
                BufferedReader bufferedReader;
                bufferedReader = null;
                try {
                    URL url = new URL(strings[0]);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    StringBuilder sb = new StringBuilder();
                    bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));
                    String json;
                    while ((json = bufferedReader.readLine()) != null) {
                        sb.append(json + "\n");
                    }
                    return sb.toString().trim();
                } catch (Exception e) {
                    return null;
                }
            }
        }

        Log.v("resource", resourceURL);
        GetURLs gu = new GetURLs();
        gu.execute(resourceURL);
    }

    //Get FoodTYpe
    private void getImage(String imageURL) {
        class GetImages extends AsyncTask<String, Void, Bitmap> {
            ProgressDialog loading;


            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(DocumentActivity.this, "Loading Menu", "Please wait...", false, false);
            }
            @Override
            protected void onPostExecute(Bitmap image) {
                super.onPostExecute(image);
                loading.dismiss();
                _docImage.setImageBitmap(image);

            }
            @Override
            protected Bitmap doInBackground(String... imageURL) {
                    URL url = null;
                    Bitmap image = null;
                    try {

                        url = new URL(imageURL[0].replace("\\","").replaceAll("^\"|\"$", ""));
                        Log.v("imageURL", url.toString());

                        image = BitmapFactory.decodeStream(url.openConnection().getInputStream());
                    } catch (MalformedURLException e) {
                        Log.e("error", "MalformedURLException", e);
                        e.printStackTrace();
                    } catch (IOException e) {
                        Log.e("error", "IOException", e);

                        e.printStackTrace();
                    }
                return image;
            }
        }
        GetImages getImages = new GetImages();
        getImages.execute(imageURL);
    }
}
