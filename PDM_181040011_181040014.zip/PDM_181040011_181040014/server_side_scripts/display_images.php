<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<title>Untitled Document</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
</head>

<body>
<?php
/*#mysql_connect("localhost","root","");
#mysql_select_db("pdm");
mysql_connect("localhost", "root", "") or
    die("Could not connect: " . mysql_error());
mysql_select_db("pdm");
$res=mysql_query("select * from images");
echo "<table>";
while($row=mysql_fetch_array($res))
{
	echo "<tr>";
	echo "<td>";?> <img src="<?php echo $row["images"]; ?>" height="100" width="100"> <?php echo "</td>";
	echo "<td>"; echo $row["name"]; echo "</td>";
	
	echo "</tr>";
	
}
echo "</table>";*/
require "conn.php";
$mysql_qry="select * from images";
$result=mysqli_query($conn, $mysql_qry);
echo "<table>";
if(mysqli_num_rows($result) > 0) {
	while($row =mysqli_fetch_assoc($result)){
	#$name =$row["name"];
	echo "<tr>";
	echo "<td>";?> <img src="<?php echo $row["images"]; ?>" height="100" width="100"> <?php echo "</td>";
	echo "<td>"; echo $row["name"]; echo "</td>";
	
	echo "</tr>";
}
}
echo "</table>";
	
?>
</body>
</html>

	