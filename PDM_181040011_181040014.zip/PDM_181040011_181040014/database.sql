-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 08, 2018 at 02:16 PM
-- Server version: 5.7.23
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pdm`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE IF NOT EXISTS `category` (
  `doc_id` int(11) NOT NULL AUTO_INCREMENT,
  `doc_name` varchar(40) NOT NULL,
  PRIMARY KEY (`doc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`doc_id`, `doc_name`) VALUES
(1, 'PAN Card'),
(2, 'Indian Passport'),
(3, 'Voter ID'),
(4, 'Driving Liscense'),
(5, 'Bank Passbook'),
(6, 'Birth Certificate'),
(7, 'School Leaving Certificate'),
(8, 'LIC Policy'),
(9, 'Telephone Bill'),
(10, 'Electricity Bill'),
(11, 'Adhar Card'),
(12, 'Employee Id'),
(13, 'Defence Id');

-- --------------------------------------------------------

--
-- Table structure for table `family`
--

DROP TABLE IF EXISTS `family`;
CREATE TABLE IF NOT EXISTS `family` (
  `family_id` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  PRIMARY KEY (`family_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `family`
--

INSERT INTO `family` (`family_id`, `email`) VALUES
('FAM95ZSAD', 'prabhumegha30@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `gov_doc`
--

DROP TABLE IF EXISTS `gov_doc`;
CREATE TABLE IF NOT EXISTS `gov_doc` (
  `family_id` varchar(20) NOT NULL,
  `email` varchar(50) NOT NULL,
  `doc_id` int(11) NOT NULL,
  `image` varchar(50) NOT NULL,
  `doc_number` varchar(40) DEFAULT NULL,
  `valid_from` date DEFAULT NULL,
  `valid_till` date DEFAULT NULL,
  `ifsc_code` varchar(11) DEFAULT NULL,
  `category` varchar(30) NOT NULL,
  KEY `doc_id` (`doc_id`),
  KEY `family_id` (`family_id`),
  KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `gov_doc`
--

INSERT INTO `gov_doc` (`family_id`, `email`, `doc_id`, `image`, `doc_number`, `valid_from`, `valid_till`, `ifsc_code`, `category`) VALUES
('FAM95ZSAD', 'prabhumegha30@gmail.com', 1, 'uploads/1.jpg', 'DUUPP9115E', '1970-01-01', '1970-01-01', '', 'Identity Proof'),
('FAM95ZSAD', 'prabhumegha30@gmail.com', 2, 'uploads/2.jpg', 'J8369854', '1999-07-01', '2018-07-01', '', 'Residence Proof'),
('FAM95ZSAD', 'prabhumegha30@gmail.com', 8, 'uploads/8.jpg', '3333333333', '2010-06-13', '2018-07-01', '', 'Residence Proof');

-- --------------------------------------------------------

--
-- Table structure for table `images`
--

DROP TABLE IF EXISTS `images`;
CREATE TABLE IF NOT EXISTS `images` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `images` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `name`, `images`) VALUES
(1, 'adharcard', 'http://localhost/images/Aadhaar-Card.jpg'),
(2, 'pancard', 'http://localhost/images/pancard.jpg'),
(3, 'passport', 'http://localhost/images/passport.jpg'),
(4, 'voterid', 'http://localhost/images/voter_id.jpg'),
(5, 'drivinglicense', 'http://localhost/images/driving_license.jpg'),
(6, 'passbook', 'http://localhost/images/passbook.png'),
(7, 'bills', 'http://localhost/images/bills.jpg'),
(8, 'manipal', 'http://localhost/images/manipal.jpg'),
(9, 'photo', 'http://localhost/images/photo.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE IF NOT EXISTS `login` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `age` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `name`, `age`, `username`, `password`) VALUES
(1, 'jai', 22, '123', '123'),
(47, 'Suman', 23, 'Suman', '123'),
(17, 'rakesh', 23, 'rakesh', 'rakesh');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

DROP TABLE IF EXISTS `notification`;
CREATE TABLE IF NOT EXISTS `notification` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `text` varchar(300) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `date` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `notification` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`id`, `email`, `text`, `status`, `date`) VALUES
(13, 'prabhumegha30@gmail.com', ' Your Indian Passport is about to expire.', 1, '2018-06-26'),
(14, 'prabhumegha30@gmail.com', ' Your LIC Policy is about to expire.', 1, '2018-06-26');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

DROP TABLE IF EXISTS `registration`;
CREATE TABLE IF NOT EXISTS `registration` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `family_id` varchar(20) NOT NULL,
  `name` varchar(40) NOT NULL,
  `address1` varchar(50) NOT NULL,
  `address2` varchar(40) NOT NULL,
  `city` varchar(20) NOT NULL,
  `zipcode` int(11) NOT NULL,
  `state` varchar(50) NOT NULL,
  `gender` varchar(7) NOT NULL,
  `dob` date NOT NULL,
  `mob_no` bigint(20) DEFAULT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `last_login` timestamp NOT NULL,
  `status` varchar(12) NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `mob_no` (`mob_no`),
  KEY `family_id` (`family_id`),
  KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`user_id`, `family_id`, `name`, `address1`, `address2`, `city`, `zipcode`, `state`, `gender`, `dob`, `mob_no`, `email`, `password`, `last_login`, `status`) VALUES
(9, 'FAM95ZSAD', 'Megha Prabhu', 'Lakshmi Kripa', 'Rajeev Nagar', 'Udupi', 576107, 'Karnataka', 'Female', '2018-06-15', 9379186101, 'prabhumegha30@gmail.com', '2cc0ee2e7eb2b7ca2974dd0559a4631a', '2018-06-25 22:33:33', 'verified');

-- --------------------------------------------------------

--
-- Table structure for table `temp_members`
--

DROP TABLE IF EXISTS `temp_members`;
CREATE TABLE IF NOT EXISTS `temp_members` (
  `family_id` varchar(20) NOT NULL,
  `memb_email` varchar(40) NOT NULL,
  `relation` varchar(25) NOT NULL,
  UNIQUE KEY `memb_email` (`memb_email`),
  KEY `family_id` (`family_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `temp_members`
--

INSERT INTO `temp_members` (`family_id`, `memb_email`, `relation`) VALUES
('FAM95ZSAD', 'jayanthiprabhu09@gmail.com', 'Mother'),
('FAM95ZSAD', 'prabhumanjunath16@gmail.com', 'Father');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `gov_doc`
--
ALTER TABLE `gov_doc`
  ADD CONSTRAINT `gov_doc_ibfk_2` FOREIGN KEY (`family_id`) REFERENCES `family` (`family_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `gov_doc_ibfk_3` FOREIGN KEY (`email`) REFERENCES `family` (`email`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `notification`
--
ALTER TABLE `notification`
  ADD CONSTRAINT `notification_ibfk_1` FOREIGN KEY (`email`) REFERENCES `registration` (`email`);

--
-- Constraints for table `registration`
--
ALTER TABLE `registration`
  ADD CONSTRAINT `registration_ibfk_1` FOREIGN KEY (`family_id`) REFERENCES `family` (`family_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `registration_ibfk_2` FOREIGN KEY (`email`) REFERENCES `family` (`email`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `temp_members`
--
ALTER TABLE `temp_members`
  ADD CONSTRAINT `temp_members_ibfk_1` FOREIGN KEY (`family_id`) REFERENCES `family` (`family_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
