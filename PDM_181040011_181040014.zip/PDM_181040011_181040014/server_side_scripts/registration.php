<?php
require "conn.php";
$id=$_POST["id"];
$name=$_POST["name"];
$age=$_POST["age"];
$username=$_POST["username"];
$password=$_POST["password"];
/*$id="22";
$name="chandu";
$age="21";
$username="456";
$password="123";*/
$mysql_qry="insert into login (id, name, age, username, password) values ('$id','$name','$age','$username','$password')";

#$results = mysqli_query($conn, $mysql_qry) or die(mysqli_error($conn));
/*$result=mysqli_query($conn, $mysql_qry);
if(mysqli_num_rows($result) > 0) {
	$row =mysqli_fetch_assoc($result);
	$name =$row["name"];
	echo "insert success !!!! Welcome ";
}
else {
	echo "insert not success";
}*/
if($conn->query($mysql_qry) === TRUE) {
	
	echo "Registration successful";
}
else {
	echo "Error:" . $mysql_qry . "<br>" . $conn->error;
}
$conn->close();
?>