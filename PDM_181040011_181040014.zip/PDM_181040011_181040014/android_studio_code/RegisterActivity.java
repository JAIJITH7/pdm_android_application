package com.example.jaijith.pdm;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class RegisterActivity extends AppCompatActivity {
    EditText id,name,age,username,password;
    String str_id,str_name,str_age,str_username,str_password;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        Button register = (Button) findViewById(R.id.register);

        id = (EditText)findViewById(R.id.id);
        name = (EditText)findViewById(R.id.name);
        age = (EditText)findViewById(R.id.age);
        username = (EditText)findViewById(R.id.username);
        password = (EditText)findViewById(R.id.password);
    }
    public void OnReg(View view) {
        String str_id = id.getText().toString();
        String str_name = name.getText().toString();
        String str_age = age.getText().toString();
        String str_username = username.getText().toString();
        String str_password = password.getText().toString();
        String type= "register";

        BackgroundWorker backgroundWorker=new BackgroundWorker(this);
        backgroundWorker.execute(type,str_id,str_name,str_age,str_username,str_password);
    }
}
