Download WAMP server
Perform localhost connection
Create database as shown in database.sql file using PHP-My-Admin
Perform the server script operation for connection, login, registration etc. 
Create an android application using android studio which includes connecting application to the localhost.
Upload the documents into wamp server file directly or by using html file (image.html) and give the address of the documents in database.
Test the application to retrieve the documents from the localhost using the java code(android studio codes).
NOTE: Make sure the application on the mobile device is connected to the localhost server same as used by the wamp server.
Make the IP configurations on the mobile device and give the IP address and port address same as used by WAMP server(port:80)